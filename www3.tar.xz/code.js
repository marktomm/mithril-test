// store.js
var store = {
    todosOrdered: [1],
    todoDetails: {
        // default for example
        1: {
            title: 'Ваша первая задача',
            isActive: true
        }
    }

};

// components/Todo.js

// Хэндлеры для правильной связки с объектом состояния
// из компонента вызываем хэндлер
// хэндлер меняет состояние
// это удобно для отладки
function handleTodoCheck(id) {
    store.todoDetails[id].isActive = !store.todoDetails[id].isActive
}

function handleTodoTitleChange(id, value) {
    // здесь могла быть запись на сервер
    console.log('id=' + id + ";value=" + value);
    store.todoDetails[id].title = value
}

// это просто объект
var Todo = {

    // функция рендеринга
    view: function (vnode) {
        var id = vnode.attrs.id;           // получаем переданные аргументы
        var todo = store.todoDetails[id];  // обращаемся к внешнему хранилищу без магии и дополнительных инструментов

        return(
            // строим объект-представление
            // класс задан в CSS-нотации, в данном случае аналог 'div.todo'
            m('.todo', {
                // обрабатываем условия
                // добавляем условный класс
                class: todo.isActive ? "active" : "no-active"
            }, [
                m('input', {
                    'type': 'checkbox',
                    onchange: handleTodoCheck.bind(null, id)  // настраиваем хэндлер с привязанным аргументом
                }),
                m('input', {
                    value: todo.title,
                    // слушаем изменения описания и меняем состояние
                    onchange: m.withAttr('value', handleTodoTitleChange.bind(null, id))
                })
            ])
        )
    }
}

// components/Todos.js
var Todos = {
    view: function (vnode) {
        return(
            m('.todos', 
                // проходимся по списку
                store.todosOrdered.map(function(todoId) {
                    // возвращаем компонент с переданными аргументами
                    return m(Todo, {id: todoId})
                }),
            )
        )
    }
}